import React from 'react'

function HeroSection() {
  return (
    <div>
        <img src="https://allgoodtales.com/wp-content/uploads/2019/07/header-1.jpg" alt="" />
    </div>
  )
}

export default HeroSection