import React, { useContext } from 'react'
import myContext from '../../context/data/myContext'

function Search() {

    const context = useContext(myContext)
    const { mode, searchkey, setSearchkey, filterType, setFilterType,
        filterPrice, setFilterPrice, product } = context

    return (
 // key: "rzp_test_B5VywgeoBC8bBf",
    // key_secret: "FB6vsXJkyCGsG3HOdTCUIb91",

        <input
            type="text"
            name="searchkey"
            value={searchkey}
            onChange={(e) => setSearchkey(e.target.value)}
            id="searchkey"
            placeholder="Search here"
            className="px-8 py-3 w-full rounded-md bg-violet-0 border-transparent outline-0 text-sm" style={{ backgroundColor: mode === 'dark' ? 'rgb(64 66 70)' : '', color: mode === 'dark' ? 'white' : '', }} />


    )
}

export default Search