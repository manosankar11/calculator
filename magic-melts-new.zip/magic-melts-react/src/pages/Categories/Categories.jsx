import React, { useContext } from 'react'
import myContext from '../../context/data/myContext'

function Categories() {

  const context = useContext(myContext)
  const { mode, searchkey, setSearchkey, filterType, setFilterType,
    filterPrice, setFilterPrice, product } = context

  return (
    <>
    
    </>
  )
}

export default Categories

