// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from 'firebase/firestore';
import {getAuth} from 'firebase/auth';


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDHo1aoYT3LcJEIQckLGeF8t6RPQcukc6A",
  authDomain: "magic-melts.firebaseapp.com",
  projectId: "magic-melts",
  storageBucket: "magic-melts.appspot.com",
  messagingSenderId: "748201217456",
  appId: "1:748201217456:web:533d9d7e3a2568fe8c1a75",
  measurementId: "G-GSGVZ9R412"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const fireDB = getFirestore(app);
const auth = getAuth(app);

export {fireDB, auth}